import { useEffect, useRef, useState } from 'react';
import './experience.css';

/** The imported experience is display-only; all patient writes stay in the workspace. */
export default function LandingExperience() {
  const host = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);
  const [mounting, setMounting] = useState(true);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let cancelled = false;
    let cleanup: (() => void) | undefined;
    setFailed(false);
    setMounting(true);
    import('./experience').then(({ mountLanding }) => {
      if (cancelled || !host.current) return;
      const experience = mountLanding(host.current, () => setAttempt(value => value + 1));
      cleanup = experience.dispose;
      setMounting(false);
    }).catch(() => { if (!cancelled) { setFailed(true); setMounting(false); } });
    return () => { cancelled = true; cleanup?.(); };
  }, [attempt]);
  return <div className="landing-experience">
    <div ref={host} data-testid="landing-experience" />
    {failed && <div className="landing-fallback"><h1>A little closer to you.</h1><p>The anatomy experience could not start. The patient workspace and model evidence are still available.</p><button className="button button-secondary" onClick={() => setAttempt(value => value + 1)}>Retry anatomy</button><a className="button button-primary" href="#workspace">Open patient workspace</a></div>}
    {mounting && <p className="landing-loading" role="status">Preparing the anatomy experience…</p>}
  </div>;
}
