import { test, expect } from '@playwright/test';

test('imported landing: body, organs, keyboard tabs, guided journey and isolated samples', async ({ page }) => {
  const errors: string[] = []; const writes: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => { if (request.method() === 'POST') writes.push(request.url()); });
  await page.emulateMedia({ reducedMotion:'reduce' });
  await page.goto('/');
  const hero = page.getByTestId('landing-experience');
  await expect(hero).toHaveAttribute('data-scene-status','ready',{timeout:20000});
  await expect(hero.getByRole('heading',{level:1})).toContainText('A little closer');
  await expect(hero.locator('#scene canvas')).toHaveCount(1);
  await expect(hero).toContainText('FICTIONAL GLUCOSE SAMPLES');
  await page.screenshot({path:'../../docs/screenshots/integrated_landing_desktop.png',fullPage:true});
  await hero.locator('[data-organ="pancreas"]').click();
  await expect(hero.locator('#dossier-title')).toContainText('Precision');
  await hero.getByRole('tab',{name:'Overview',exact:true}).focus();
  await page.keyboard.press('End');
  await expect(hero.getByRole('tab',{name:'Model connection'})).toBeFocused();
  await expect(hero.locator('#tab-biomarkers')).toContainText('does not measure insulin secretion');
  await expect(hero.locator('#tab-biomarkers')).not.toContainText('Target:');
  await page.screenshot({path:'../../docs/screenshots/integrated_landing_pancreas.png',fullPage:true});
  await hero.getByRole('button',{name:'Guided Journey',exact:true}).click();
  for (const organ of ['Digestive Tract','Pancreas','Liver','Skeletal Muscle','Adipose Tissue']) {
    await hero.locator('#primary-explore-btn').click();
    await expect(hero.locator('.organ-nav .active')).toContainText(organ);
  }
  await expect(hero.locator('#primary-explore-btn')).toContainText('Finish journey');
  await hero.locator('#primary-explore-btn').click();
  await expect(hero.getByRole('button',{name:'Guided Journey',exact:true})).toHaveAttribute('aria-pressed','false');
  await hero.getByRole('slider',{name:'Select sample reading'}).fill('5');
  await expect(hero.locator('#glucose-value')).toHaveText('—');
  await hero.getByRole('button',{name:'Scripted curve',exact:true}).click();
  await expect(hero.locator('#glucose-value')).toHaveText('164');
  await hero.getByRole('button',{name:'About this experience'}).click();
  await expect(hero.locator('dialog')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(hero.locator('dialog')).not.toBeVisible();
  expect(writes).toEqual([]);
  expect(errors).toEqual([]);
});

test('landing remount, mobile navigation and failure preserve application access', async ({ page }) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.goto('/');
  const nav=page.getByRole('navigation',{name:'Main navigation'});
  for (let i=0;i<3;i++) {
    await expect(page.getByTestId('landing-experience')).toHaveAttribute('data-scene-status','ready',{timeout:20000});
    await nav.getByRole('link',{name:'Evidence',exact:true}).click();
    await expect(page.getByTestId('landing-experience')).toHaveCount(0);
    await nav.getByRole('link',{name:'Overview',exact:true}).click();
  }
  for (const width of [1024,768,400,360]) {
    await page.setViewportSize({width,height:900});
    await expect(page.getByTestId('landing-experience')).toHaveAttribute('data-scene-status','ready',{timeout:20000});
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
    await page.screenshot({path:`../../docs/screenshots/integrated_landing_${width}.png`,fullPage:true});
  }
  await page.getByTestId('landing-experience').getByRole('link',{name:/Open patient workspace/}).click();
  await expect(page.getByLabel('Synthetic scenario')).toBeVisible();
  await expect(page.locator('[data-destination=workspace]').getByTestId('anatomy-stage')).toHaveAttribute('data-status','ready',{timeout:20000});
  expect(errors).toEqual([]);
});

test('failed landing mesh leaves workspace and evidence available', async ({ page }) => {
  const errors:string[]=[]; page.on('pageerror', error=>errors.push(error.message));
  await page.route('**/models/glucotwin_anatomy.glb', route=>route.abort());
  await page.goto('/');
  const hero=page.getByTestId('landing-experience');
  await expect(hero).toHaveAttribute('data-scene-status','error',{timeout:20000});
  await expect(hero.getByRole('button',{name:'Restore Scene'})).toBeVisible();
  await page.unroute('**/models/glucotwin_anatomy.glb');
  await hero.getByRole('button',{name:'Restore Scene'}).click();
  await expect(hero).toHaveAttribute('data-scene-status','ready',{timeout:20000});
  await hero.getByRole('link',{name:/Model evidence/}).click();
  await expect(page.getByRole('heading',{level:1})).toHaveText('What the prototype demonstrates');
  expect(errors).toEqual([]);
});
