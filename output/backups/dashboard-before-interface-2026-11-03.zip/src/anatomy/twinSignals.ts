import type { Reading } from '../types';

export type TwinSignal = { glucose: number | null; color: string; label: string; playing: boolean };
export type TwinPoint = { minutes: number; glucose: number; observedAt: string };
export type ScenarioId = 'rise' | 'surge' | 'dip';

// Storyboard fixtures, NOT fitted forecasts or intervention response estimates.
export const SCENARIOS: Record<ScenarioId, { title: string; description: string; values: number[] }> = {
  rise: { title: 'A · Rise and settle', description: 'A fictional modest rise followed by a return toward baseline.', values: [0, 9, 18, 25, 29, 23, 14, 7, 2] },
  surge: { title: 'B · Larger excursion', description: 'A fictional larger rise to demonstrate the event overlay.', values: [0, 17, 36, 55, 67, 60, 48, 33, 20] },
  dip: { title: 'C · Dip and return', description: 'An invented dip to 65 mg/dL, then recovery. No low-glucose predictor is running.', values: [] },
};

export function mockTimeline(baseline: number | null, baselineAt: string | undefined, scenario: ScenarioId): TwinPoint[] {
  const start = Date.parse(baselineAt || '');
  if (baseline === null || !Number.isFinite(baseline) || !Number.isFinite(start)) return [];
  const values = scenario === 'dip'
    ? [baseline, baseline * .8 + 65 * .2, baseline * .5 + 65 * .5, 74, 65, 79, 95, 110, 120]
    : SCENARIOS[scenario].values.map(delta => baseline + delta);
  return values.map((glucose, index) => ({ minutes: index * 15, glucose: Math.round(glucose), observedAt: new Date(start + index * 15 * 60000).toISOString() }));
}

export function recordedTimeline(readings: Reading[], baselineAt: string | undefined): { points: TwinPoint[]; issue: string } {
  const baseline = Date.parse(baselineAt || '');
  if (!Number.isFinite(baseline)) return { points: [], issue: 'A valid meal timestamp is needed to align the body and timeline.' };
  const byTime = new Map<number, number>();
  let invalid = false;
  for (const row of readings) {
    const time = Date.parse(row.observedAt);
    if (!Number.isFinite(time) || !Number.isFinite(row.glucoseMgDl) || row.glucoseMgDl <= 0) { invalid = true; continue; }
    if (time < baseline - 120 * 60000 || time > baseline + 120 * 60000) continue;
    if (byTime.has(time) && byTime.get(time) !== row.glucoseMgDl) return { points: [], issue: 'Conflicting glucose values share a timestamp. The visual replay is withheld until the data is corrected.' };
    byTime.set(time, row.glucoseMgDl);
  }
  if (invalid) return { points: [], issue: 'Invalid glucose or timestamps were returned. The visual replay is withheld until the data is corrected.' };
  return { points: [...byTime].sort(([a], [b]) => a - b).map(([time, glucose]) => ({ minutes: (time - baseline) / 60000, glucose, observedAt: new Date(time).toISOString() })), issue: '' };
}

// Display bands only. They are not patient risk categories or organ health scores.
export function glucoseSignal(glucose: number | null, playing: boolean): TwinSignal {
  if (glucose === null) return { glucose, playing: false, color: '#9bb3bd', label: 'No reading' };
  if (glucose < 70) return { glucose, playing, color: '#b9a7ff', label: 'Below 70 mg/dL' };
  if (glucose >= 180) return { glucose, playing, color: '#ffb66f', label: 'At or above 180 mg/dL' };
  return { glucose, playing, color: '#75ddd3', label: '70 to below 180 mg/dL' };
}

export function utcLabel(value: string | undefined) {
  return value ? new Date(value).toISOString().replace('T', ' ').slice(0, 16) + ' UTC' : 'No timestamp';
}
