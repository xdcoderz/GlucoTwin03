import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { cameraStage, ORGAN_IDS, ORGANS, type OrganId, type ViewId } from "./organs";
import type { TwinSignal } from './twinSignals';
import { gsap, easeSpatial } from '../motion/gsap';

type Callbacks = {
  onPick: (id: ViewId) => void;
  onStage: (stage: ReturnType<typeof cameraStage>) => void;
  onMarkers: (markers: { id: OrganId; x: number; y: number; visible: boolean }[]) => void;
  onFailure: () => void;
};

export type AnatomyScene = {
  focus: (id: ViewId, instant?: boolean) => void;
  zoom: (direction: "in" | "out", instant?: boolean) => void;
  rotate: (direction: number) => void;
  transparency: (value: number) => void;
  setSignal: (signal: TwinSignal) => void;
  setOverlayVisible: (visible: boolean) => void;
  dispose: () => void;
};

/** Self-contained schematic geometry. No external models, textures, or patient scans. */
export function createAnatomyScene(host: HTMLDivElement, canvas: HTMLCanvasElement, callbacks: Callbacks): AnatomyScene {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: "low-power" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 50);
  camera.position.set(0, 0.25, 11.6);
  const controls = new OrbitControls(camera, canvas);
  controls.target.set(0, 0.2, 0);
  controls.enablePan = false;
  controls.enableDamping = false;
  controls.enableZoom = false;
  controls.minDistance = 1.85;
  controls.maxDistance = 13;
  controls.minPolarAngle = Math.PI * 0.22;
  controls.maxPolarAngle = Math.PI * 0.78;
  controls.rotateSpeed = 0.6;
  controls.zoomSpeed = 0.8;
  // Neutral illumination preserves the tissue palette; teal light would shift its hue.
  scene.add(new THREE.HemisphereLight(0xffffff, 0x727272, 1.6));
  const key = new THREE.DirectionalLight(0xffffff, 2.2);
  key.position.set(3, 6, 7); scene.add(key);
  const rim = new THREE.DirectionalLight(0xffffff, 1.3);
  rim.position.set(-4, 2, -4); scene.add(rim);

  const body = new THREE.Group();
  scene.add(body);
  // A neutral translucent locator, not a representation of this patient's skin tone.
  const shell = new THREE.MeshPhysicalMaterial({ color: 0xc4bcb1, transparent: true, opacity: 0.2, roughness: 0.65, metalness: 0, side: THREE.DoubleSide, depthWrite: false });
  const boneMaterial = new THREE.MeshStandardMaterial({ color: 0xe4dac5, transparent: true, opacity: 0.24, roughness: 0.7, depthWrite: false });
  const shellParts: THREE.Mesh[] = [];
  const pickables: THREE.Mesh[] = [];
  const organMeshes = new Map<OrganId, THREE.Mesh[]>();
  const organMaterials = new Map<OrganId, THREE.MeshStandardMaterial>();
  ORGAN_IDS.forEach(id => {
    organMeshes.set(id, []);
    organMaterials.set(id, new THREE.MeshStandardMaterial({ color: ORGANS[id].color, roughness: ORGANS[id].roughness, metalness: 0, transparent: true, opacity: 1, emissive: 0x000000, emissiveIntensity: 0 }));
  });

  function add(geometry: THREE.BufferGeometry, material: THREE.Material, parent: THREE.Group = body, organ?: OrganId): THREE.Mesh {
    const mesh = new THREE.Mesh(geometry, material);
    parent.add(mesh);
    if (organ) {
      mesh.userData.organ = organ;
      mesh.renderOrder = 2;
      pickables.push(mesh);
      organMeshes.get(organ)!.push(mesh);
    } else if (material === shell) shellParts.push(mesh);
    return mesh;
  }

  function ellipsoid(x: number, y: number, z: number, sx: number, sy: number, sz: number, material: THREE.Material, organ?: OrganId): THREE.Mesh {
    const mesh = add(new THREE.SphereGeometry(1, 32, 24), material, body, organ);
    mesh.position.set(x, y, z); mesh.scale.set(sx, sy, sz);
    return mesh;
  }

  function limb(start: THREE.Vector3, end: THREE.Vector3, radii: number[], material: THREE.Material, organ?: OrganId) {
    const length = start.distanceTo(end);
    const points = radii.map((r, i) => new THREE.Vector2(r, length * i / (radii.length - 1)));
    const geometry = new THREE.LatheGeometry(new THREE.SplineCurve(points).getPoints(24), 28);
    geometry.translate(0, -length / 2, 0);
    const mesh = add(geometry, material, body, organ);
    mesh.position.copy(start).add(end).multiplyScalar(0.5);
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), end.clone().sub(start).normalize());
    return mesh;
  }

  function tube(points: number[][], radius: number, material: THREE.Material, organ?: OrganId) {
    return add(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p as [number, number, number]))), Math.max(24, points.length * 9), radius, 10, false), material, body, organ);
  }

  // Neutral, approximate human silhouette. Front of body faces +Z; patient right is viewer left.
  const profile = [[0.08, -0.08], [.43, -.02], [.57, .22], [.55, .5], [.54, .75], [.63, 1.12], [.77, 1.47], [.84, 1.73], [.74, 1.88], [.43, 2.02], [.23, 2.10]];
  const torso = add(new THREE.LatheGeometry(new THREE.SplineCurve(profile.map(p => new THREE.Vector2(p[0], p[1]))).getPoints(64), 48), shell);
  torso.scale.z = .53;
  ellipsoid(0, 2.45, 0, .31, .43, .30, shell);
  limb(new THREE.Vector3(0, 1.99, 0), new THREE.Vector3(0, 2.22, 0), [.20, .18, .19], shell);
  ellipsoid(-.31, 2.45, 0, .055, .105, .065, shell);
  ellipsoid(.31, 2.45, 0, .055, .105, .065, shell);
  ellipsoid(0, 2.44, .28, .055, .09, .065, shell);
  // Collar bones and a quiet spinal landmark keep the transparent shell legible.
  tube([[-.68, 1.84, .24], [-.35, 1.9, .22], [0, 1.85, .20], [.35, 1.9, .22], [.68, 1.84, .24]], .018, boneMaterial);
  tube([[0, -.1, -.2], [0, .6, -.24], [0, 1.3, -.22], [0, 2.1, -.05]], .033, boneMaterial);
  for (const sign of [-1, 1]) {
    const v = (x: number, y: number, z = 0) => new THREE.Vector3(sign * x, y, z);
    ellipsoid(sign * .77, 1.67, 0, .245, .28, .245, shell);
    limb(v(.82, 1.62), v(1.06, .82, .015), [.21, .225, .175, .135], shell);
    ellipsoid(sign * 1.06, .81, .015, .14, .15, .14, shell);
    limb(v(1.06, .82, .015), v(1.22, .05, .05), [.14, .16, .13, .095], shell);
    ellipsoid(sign * 1.23, -.09, .055, .11, .19, .07, shell);
    for (let f = 0; f < 4; f++) {
      const x = 1.16 + f * .047;
      limb(v(x, -.16, .07), v(x + .015, -.40 + Math.abs(f - 1.5) * .035, .075), [.025, .026, .019, .01], shell);
    }
    limb(v(1.15, -.04, .07), v(1.07, -.21, .1), [.035, .029, .013], shell);
    limb(v(.32, .08), v(.35, -1.19, .02), [.27, .28, .23, .17], shell);
    ellipsoid(sign * .35, -1.19, .035, .17, .17, .17, shell);
    limb(v(.35, -1.19, .02), v(.38, -2.45, -.015), [.17, .20, .15, .09], shell);
    ellipsoid(sign * .38, -2.57, .13, .14, .12, .30, shell);
    // Representative muscle and fat regions, not a measured tissue segmentation.
    limb(v(.32, -.15, .07), v(.35, -1.02, .08), [.15, .19, .15, .08], organMaterials.get('muscle')!, 'muscle');
    limb(v(.84, 1.52, .025), v(1.03, .91, .04), [.11, .13, .10, .05], organMaterials.get('muscle')!, 'muscle');
    ellipsoid(sign * .47, .23, .025, .14, .27, .22, organMaterials.get('fat')!, 'fat');
  }

  const liverShape = new THREE.Shape();
  liverShape.moveTo(-.67, .05);
  liverShape.bezierCurveTo(-.79, .35, -.46, .51, -.06, .37);
  liverShape.bezierCurveTo(.14, .31, .34, .28, .45, .13);
  liverShape.bezierCurveTo(.26, .02, .09, .02, -.04, -.09);
  liverShape.bezierCurveTo(-.25, -.27, -.61, -.21, -.67, .05);
  const liver = add(new THREE.ExtrudeGeometry(liverShape, { depth: .19, bevelEnabled: true, bevelThickness: .065, bevelSize: .07, bevelSegments: 4, steps: 1, curveSegments: 24 }), organMaterials.get('liver')!, body, 'liver');
  liver.position.set(-.13, .99, -.08);
  liver.rotation.y = -.12;

  // Digestive tract is represented by stomach and small-intestinal loops.
  const stomach = ellipsoid(.35, .98, .12, .22, .35, .15, organMaterials.get('gut')!, 'gut');
  stomach.rotation.z = -.3;
  tube([[.4, 1.59, .03], [.37, 1.32, .05], [.35, 1.15, .12]], .048, organMaterials.get('gut')!, 'gut');
  for (let row = 0; row < 4; row++) {
    const y = .37 - row * .14;
    tube([[-.29, y, .12], [-.36, y + .07, .12], [-.13, y + .10, .20], [.1, y, .20], [.30, y + .07, .12], [.26, y - .05, .12], [0, y - .06, .20], [-.29, y - .12, .12]], .053, organMaterials.get('gut')!, 'gut');
  }

  const pancreaticPath = [[-.38, .61, .17], [-.27, .65, .12], [-.05, .69, .065], [.19, .72, .035], [.43, .80, .015], [.58, .84, -.005]];
  const pancreasCurve = new THREE.CatmullRomCurve3(pancreaticPath.map(p => new THREE.Vector3(...p as [number, number, number])));
  tube(pancreaticPath, .073, organMaterials.get('pancreas')!, 'pancreas');
  for (let i = 0; i < 24; i++) {
    const t = i / 23;
    const center = pancreasCurve.getPoint(t);
    const radius = .095 - t * .055;
    const lobe = ellipsoid(center.x, center.y + Math.sin(i * 2.7) * .035, center.z, radius * 1.2, radius * (.8 + .13 * Math.sin(i)), radius, organMaterials.get('pancreas')!, 'pancreas');
    lobe.rotation.z = .3;
  }
  // The pancreatic duct is internal: don't paint a bright exposed tube on the surface.

  // Separate data overlay. Its paths, speed, and density carry no physiological meaning.
  // Anatomy materials are never changed by glucose or model score.
  const overlay = new THREE.Group();
  body.add(overlay);
  const signalMaterial = new THREE.MeshBasicMaterial({ color: 0x75ddd3, transparent: true, opacity: .65, depthWrite: false });
  const pathMaterial = new THREE.MeshBasicMaterial({ color: 0x75ddd3, transparent: true, opacity: .26, depthWrite: false });
  const haloMaterial = new THREE.MeshBasicMaterial({ color: 0x75ddd3, transparent: true, opacity: .5, depthWrite: false, side: THREE.DoubleSide });
  const paths = [
    [[0, -.2, .38], [-.2, .28, .39], [.08, .68, .39], [-.25, 1.1, .40], [0, 1.7, .38]],
    [[.08, .68, .39], [.44, 1.16, .39], [.78, 1.47, .3], [1.02, .92, .26]],
    [[.08, .68, .39], [-.44, 1.16, .39], [-.78, 1.47, .3], [-1.02, .92, .26]],
    [[.08, .68, .39], [.32, .05, .35], [.35, -.8, .32], [.38, -1.9, .23]],
    [[.08, .68, .39], [-.32, .05, .35], [-.35, -.8, .32], [-.38, -1.9, .23]],
  ].map(points => new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p as [number, number, number]))));
  const particles: { mesh: THREE.Mesh; curve: THREE.CatmullRomCurve3; offset: number }[] = [];
  const dotGeometry = new THREE.SphereGeometry(.024, 10, 8);
  paths.forEach(curve => {
    const ribbon = new THREE.Mesh(new THREE.TubeGeometry(curve, 56, .009, 6, false), pathMaterial);
    ribbon.renderOrder = 4; overlay.add(ribbon);
    for (let i = 0; i < 5; i++) {
      const dot = new THREE.Mesh(dotGeometry, signalMaterial);
      dot.renderOrder = 5; overlay.add(dot); particles.push({ mesh: dot, curve, offset: i / 5 });
    }
  });
  const halo = new THREE.Mesh(new THREE.TorusGeometry(.19, .009, 8, 64), haloMaterial);
  halo.position.set(.08, .68, .42); halo.scale.x = 1.7; halo.renderOrder = 5; overlay.add(halo);
  overlay.visible = false;

  const grid = new THREE.GridHelper(8, 24, 0x24505a, 0x16313d);
  grid.position.y = -2.73;
  scene.add(grid);
  const pedestal = add(new THREE.CylinderGeometry(.84, .91, .035, 64), new THREE.MeshStandardMaterial({ color: 0x173845, transparent: true, opacity: .6 }));
  pedestal.position.set(0, -2.73, 0);

  let disposed = false;
  let active: ViewId = 'body';
  let shellOpacity = .20;
  let cameraTween: gsap.core.Tween | null = null;
  let signalFrame = 0;
  let signalMoving = false;
  let overlayEnabled = true;
  let hasSignal = false;
  let inViewport = true;
  let flowOffset = 0;
  let lastFlowTime = 0;
  let lastStage = '';
  let automaticAbdomen = true;
  let transitioning = false;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const goalPosition = camera.position.clone();
  const goalTarget = controls.target.clone();

  function updateDots() {
    particles.forEach(({ mesh, curve, offset }) => mesh.position.copy(curve.getPoint((offset + flowOffset) % 1)));
  }
  function flowTick(now: number) {
    if (disposed || !signalMoving || !overlayEnabled || reducedMotion.matches || document.hidden || !inViewport) return;
    // Bound GPU work to 30 fps. Playback timestamps remain independent of draw rate.
    if (!lastFlowTime || now - lastFlowTime >= 1000 / 30) {
      if (lastFlowTime) flowOffset = (flowOffset + Math.min(now - lastFlowTime, 100) / 8000) % 1;
      lastFlowTime = now;
      updateDots(); render();
    }
    signalFrame = requestAnimationFrame(flowTick);
  }
  function syncFlow() {
    if (reducedMotion.matches && cameraTween?.isActive()) cameraTween.progress(1);
    cancelAnimationFrame(signalFrame); lastFlowTime = 0;
    if (signalMoving && overlayEnabled && !reducedMotion.matches && !document.hidden && inViewport) signalFrame = requestAnimationFrame(flowTick);
  }
  const visibilityObserver = new IntersectionObserver(entries => { inViewport = entries[0].isIntersecting; syncFlow(); });
  visibilityObserver.observe(host);
  document.addEventListener('visibilitychange', syncFlow);
  reducedMotion.addEventListener('change', syncFlow);
  updateDots();

  function render() {
    if (disposed) return;
    const distance = camera.position.distanceTo(controls.target);
    const stage = cameraStage(distance);
    if (stage !== lastStage) { lastStage = stage; callbacks.onStage(stage); }
    const near = THREE.MathUtils.clamp((8.5 - distance) / 5, 0, 1);
    shell.opacity = shellOpacity * (1 - near * .87);
    organMaterials.forEach((material, id) => {
      const selected = active === id;
      // Reveal the pancreas through the schematic surrounding context in close view.
      material.opacity = active === 'body' ? 1 : selected ? 1 : (id === 'gut' && active === 'pancreas' ? .12 : .22);
      material.depthWrite = material.opacity > .8;
      // Selection reveals context; it never makes tissue emit light or change hue.
    });
    renderer.render(scene, camera);
    callbacks.onMarkers(ORGAN_IDS.map(id => {
      const projected = new THREE.Vector3(...ORGANS[id].center).project(camera);
      return { id, x: (projected.x + 1) / 2 * host.clientWidth, y: (1 - projected.y) / 2 * host.clientHeight,
        visible: projected.z > -1 && projected.z < 1 && Math.abs(projected.x) < .85 && Math.abs(projected.y) < .9 && (active === 'body' || active === id) };
    }));
  }

  function animateTo(position: THREE.Vector3, target: THREE.Vector3, instant = false) {
    cameraTween?.kill();
    transitioning = true;
    goalPosition.copy(position); goalTarget.copy(target);
    if (instant || reducedMotion.matches) {
      camera.position.copy(position); controls.target.copy(target); controls.update(); transitioning = false; render();
      return;
    }
    const startPosition = camera.position.clone();
    const startTarget = controls.target.clone();
    const progress = { value: 0 };
    cameraTween = gsap.to(progress, { value: 1, duration: .5, ease: easeSpatial,
      onUpdate: () => {
        if (disposed) return;
        camera.position.lerpVectors(startPosition, goalPosition, progress.value);
        controls.target.lerpVectors(startTarget, goalTarget, progress.value);
        controls.update(); render();
      }, onComplete: () => { transitioning = false; },
    });
  }

  function focus(id: ViewId, instant = false) {
    active = id;
    automaticAbdomen = id === 'body';
    const target = id === 'body' ? new THREE.Vector3(0, .2, 0) : new THREE.Vector3(...ORGANS[id].center);
    const distance = id === 'body' ? 11.6 : ORGANS[id].distance;
    animateTo(target.clone().add(new THREE.Vector3(.08, .10, distance)), target, instant);
  }

  function zoom(direction: 'in' | 'out', instant = false) {
    const currentDistance = camera.position.distanceTo(controls.target);
    const next = THREE.MathUtils.clamp(currentDistance * (direction === 'in' ? .75 : 1.4), controls.minDistance, controls.maxDistance);
    if (active === 'body' && next < 7.8) {
      active = 'pancreas'; automaticAbdomen = false; callbacks.onPick('pancreas');
    }
    const target = active === 'body' ? new THREE.Vector3(0, .2, 0) : new THREE.Vector3(...ORGANS[active].center);
    const directionVector = camera.position.clone().sub(controls.target).normalize();
    animateTo(target.clone().addScaledVector(directionVector, next), target, instant);
  }

  let pointerStart = { x: 0, y: 0 };
  const raycaster = new THREE.Raycaster();
  function pointerDown(event: PointerEvent) {
    cameraTween?.kill();
    transitioning = false;
    canvas.focus({ preventScroll: true });
    controls.enableZoom = true;
    pointerStart = { x: event.clientX, y: event.clientY };
  }
  function pointerUp(event: PointerEvent) {
    if (Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y) > 6) return;
    const rect = canvas.getBoundingClientRect();
    raycaster.setFromCamera(new THREE.Vector2((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1), camera);
    const hit = raycaster.intersectObjects(pickables, false).find(result => result.object.userData.organ);
    if (hit) { const id = hit.object.userData.organ as OrganId; callbacks.onPick(id); focus(id); }
  }
  function changed() {
    // Wheel/pinch dolly starts at the whole body and progressively centers the abdomen.
    const distance = camera.position.distanceTo(controls.target);
    if (!transitioning && automaticAbdomen && active === 'body') {
      const t = THREE.MathUtils.clamp((11.6 - distance) / 6.8, 0, 1);
      controls.target.lerpVectors(new THREE.Vector3(0, .2, 0), new THREE.Vector3(...ORGANS.pancreas.center), t);
      if (distance < 6.2) {
        active = 'pancreas'; automaticAbdomen = false; callbacks.onPick('pancreas');
        const direction = camera.position.clone().sub(controls.target).normalize();
        controls.target.set(...ORGANS.pancreas.center);
        camera.position.copy(controls.target).addScaledVector(direction, distance);
      }
      camera.lookAt(controls.target);
    }
    render();
  }
  function keyboard(event: KeyboardEvent) {
    if (event.key === '+' || event.key === '=') { event.preventDefault(); zoom('in', true); }
    if (event.key === '-') { event.preventDefault(); zoom('out', true); }
    if (event.key.toLowerCase() === 'r' || event.key === 'Escape') { event.preventDefault(); callbacks.onPick('body'); focus('body', true); }
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); rotate(event.key === 'ArrowLeft' ? -1 : 1); }
  }
  function rotate(direction: number) {
    cameraTween?.kill(); transitioning = false;
    const offset = camera.position.clone().sub(controls.target);
    offset.applyAxisAngle(new THREE.Vector3(0, 1, 0), direction * .24);
    camera.position.copy(controls.target).add(offset); controls.update(); render();
  }
  function allowZoom() { controls.enableZoom = true; }
  function stopZoom() { controls.enableZoom = false; }
  function interrupt() { cameraTween?.kill(); transitioning = false; }
  function contextLost(event: Event) { event.preventDefault(); signalMoving = false; cancelAnimationFrame(signalFrame); cameraTween?.kill(); callbacks.onFailure(); }
  function resize() {
    const width = host.clientWidth; const height = host.clientHeight;
    if (!width || !height) return;
    camera.aspect = width / height;
    camera.updateProjectionMatrix(); renderer.setSize(width, height, false); render();
  }
  const observer = new ResizeObserver(resize);
  observer.observe(host);
  controls.addEventListener('change', changed);
  controls.addEventListener('start', interrupt);
  canvas.addEventListener('pointerdown', pointerDown);
  canvas.addEventListener('pointerup', pointerUp);
  canvas.addEventListener('keydown', keyboard);
  canvas.addEventListener('focus', allowZoom);
  canvas.addEventListener('blur', stopZoom);
  canvas.addEventListener('webglcontextlost', contextLost);
  controls.update(); resize();

  return {
    focus, zoom, rotate,
    transparency(value) { shellOpacity = value; render(); },
    setOverlayVisible(visible) {
      overlayEnabled = visible; overlay.visible = visible && hasSignal;
      syncFlow(); render();
    },
    setSignal(signal) {
      hasSignal = signal.glucose !== null;
      overlay.visible = overlayEnabled && hasSignal;
      signalMaterial.color.set(signal.color); pathMaterial.color.set(signal.color); haloMaterial.color.set(signal.color);
      const level = THREE.MathUtils.clamp(((signal.glucose ?? 40) - 40) / 260, 0, 1);
      signalMaterial.opacity = .35 + .65 * level;
      pathMaterial.opacity = .12 + .4 * level;
      haloMaterial.opacity = .2 + .6 * level;
      signalMoving = signal.playing && signal.glucose !== null;
      // Fixed particle speed and fixed organ geometry avoid implying measured organ activity.
      syncFlow(); render();
    },
    dispose() {
      disposed = true; cameraTween?.kill(); cancelAnimationFrame(signalFrame); observer.disconnect(); visibilityObserver.disconnect();
      document.removeEventListener('visibilitychange', syncFlow); reducedMotion.removeEventListener('change', syncFlow);
      controls.removeEventListener('change', changed); controls.removeEventListener('start', interrupt); controls.dispose();
      canvas.removeEventListener('pointerdown', pointerDown); canvas.removeEventListener('pointerup', pointerUp);
      canvas.removeEventListener('keydown', keyboard); canvas.removeEventListener('focus', allowZoom); canvas.removeEventListener('blur', stopZoom);
      canvas.removeEventListener('webglcontextlost', contextLost);
      const geometries = new Set<THREE.BufferGeometry>(); const materials = new Set<THREE.Material>();
      scene.traverse(object => {
        const mesh = object as THREE.Mesh;
        if (mesh.geometry) geometries.add(mesh.geometry);
        if (mesh.material) (Array.isArray(mesh.material) ? mesh.material : [mesh.material]).forEach(material => materials.add(material));
      });
      geometries.forEach(geometry => geometry.dispose()); materials.forEach(material => material.dispose());
      renderer.dispose();
    },
  };
}
