import { test, expect } from '@playwright/test';

test('landing columns, marker labels, keyboard tabs and isolated samples', async ({ page }) => {
  const errors: string[] = []; const writes: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => { if (request.method() === 'POST') writes.push(request.url()); });
  await page.emulateMedia({ reducedMotion:'reduce' });
  await page.goto('/');
  const hero = page.getByTestId('landing-experience');
  await expect(hero).toHaveAttribute('data-scene-status','ready',{timeout:20000});
  const intro=page.getByTestId('landing-introduction');
  await expect(intro.getByRole('heading',{level:1})).toContainText('A little closer');
  await expect(page.locator('.safety-banner')).toHaveCount(0);
  const boxes=await page.evaluate(()=>Object.fromEntries(['.site-topbar','.landing-introduction','.anatomy-workbench','.landing-model-column','.editorial-container','.insight'].map(selector=>[selector,document.querySelector(selector)!.getBoundingClientRect().toJSON()])));
  expect(boxes['.landing-introduction'].top).toBeGreaterThanOrEqual(boxes['.site-topbar'].bottom-1);
  expect(boxes['.anatomy-workbench'].top).toBeGreaterThanOrEqual(boxes['.landing-introduction'].bottom-1);
  expect(boxes['.landing-model-column'].width/(boxes['.landing-model-column'].width+boxes['.editorial-container'].width)).toBeCloseTo(.7,2);
  expect(boxes['.insight'].top).toBeGreaterThanOrEqual(boxes['.anatomy-workbench'].bottom);
  await expect(hero.locator('#explore-mode')).not.toBeVisible();
  await expect(hero.locator('#tour-mode')).not.toBeVisible();
  await expect(hero.locator('#about-button')).not.toBeVisible();
  await expect(hero.locator('.scene-tools #opacity')).toBeVisible();
  await expect(hero.locator('.scene-tools #zoom-in')).toBeVisible();
  await expect(hero.locator('.insight .view-settings')).toHaveCount(0);
  await expect(hero.locator('.spatial-hotspot')).toHaveCount(5);
  await expect(hero.locator('.hotspot-pill:visible')).toHaveCount(0);
  const marker=hero.locator('[data-organ-hotspot=pancreas]');
  await marker.hover();
  await expect(marker.getByRole('tooltip')).toBeVisible();
  await page.mouse.move(0,0);
  await expect(marker.getByRole('tooltip')).not.toBeVisible();
  await marker.click();
  await page.mouse.move(0,0);
  await expect(marker).toHaveAttribute('aria-expanded','true');
  await expect(marker.getByRole('tooltip')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(marker.getByRole('tooltip')).not.toBeVisible();
  await marker.focus();await page.keyboard.press('Tab');await page.keyboard.press('Shift+Tab');
  await expect(marker.getByRole('tooltip')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(hero.locator('#scene canvas')).toHaveCount(1);
  await expect(hero).toContainText('FICTIONAL GLUCOSE SAMPLES');
  await page.screenshot({path:'../../docs/screenshots/integrated_landing_desktop.png',fullPage:true});
  await hero.locator('[data-organ="pancreas"]').click();
  await expect(hero.locator('#dossier-title')).toContainText('Precision');
  await expect(intro.getByRole('heading',{level:1})).toContainText('A little closer');
  await hero.getByRole('tab',{name:'Overview',exact:true}).focus();
  await page.keyboard.press('End');
  await expect(hero.getByRole('tab',{name:'Model connection'})).toBeFocused();
  await expect(hero.locator('#tab-biomarkers')).toContainText('does not measure insulin secretion');
  await expect(hero.locator('#tab-biomarkers')).not.toContainText('Target:');
  await page.screenshot({path:'../../docs/screenshots/integrated_landing_pancreas.png',fullPage:true});
  await hero.locator('#reset-camera').click();
  await expect(hero.locator('#dossier-title')).toContainText('Connected systems');
  await hero.getByRole('slider',{name:'Select sample reading'}).fill('5');
  await expect(hero.locator('#glucose-value')).toHaveText('—');
  await hero.getByRole('button',{name:'Scripted curve',exact:true}).click();
  await expect(hero.locator('#glucose-value')).toHaveText('164');
  await expect(hero.locator('dialog')).not.toBeVisible();
  expect(writes).toEqual([]);
  expect(errors).toEqual([]);
});

test('landing remount, mobile navigation and failure preserve application access', async ({ page }) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.goto('/');
  const nav=page.getByRole('navigation',{name:'Main navigation'});
  for (let i=0;i<3;i++) {
    await expect(page.getByTestId('landing-experience')).toHaveAttribute('data-scene-status','ready',{timeout:20000});
    await nav.getByRole('link',{name:'Evidence',exact:true}).click();
    await expect(page.getByTestId('landing-experience')).toHaveCount(0);
    await nav.getByRole('link',{name:'Overview',exact:true}).click();
  }
  for (const width of [1024,768,400,360]) {
    await page.setViewportSize({width,height:900});
    await expect(page.getByTestId('landing-experience')).toHaveAttribute('data-scene-status','ready',{timeout:20000});
    expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
    const model=await heroModelBox();
    const information=await page.locator('.editorial-container').boundingBox();
    if(width<=900) expect(information!.y).toBeGreaterThanOrEqual(model!.y+model!.height-1);
    else expect(model!.width/(model!.width+information!.width)).toBeCloseTo(.7,2);
    await page.screenshot({path:`../../docs/screenshots/integrated_landing_${width}.png`,fullPage:true});
  }
  await page.getByTestId('landing-introduction').getByRole('link',{name:/Open patient workspace/}).click();
  await expect(page.getByLabel('Synthetic scenario')).toBeVisible();
  await expect(page.locator('[data-destination=workspace]').getByTestId('anatomy-stage')).toHaveAttribute('data-status','ready',{timeout:20000});
  expect(errors).toEqual([]);
  async function heroModelBox(){return page.locator('.landing-model-column').boundingBox();}
});

test('failed landing mesh leaves workspace and evidence available', async ({ page }) => {
  const errors:string[]=[]; page.on('pageerror', error=>errors.push(error.message));
  await page.route('**/models/glucotwin_anatomy.glb', route=>route.abort());
  await page.goto('/');
  const hero=page.getByTestId('landing-experience');
  await expect(hero).toHaveAttribute('data-scene-status','error',{timeout:20000});
  await expect(hero.getByRole('button',{name:'Restore Scene'})).toBeVisible();
  await page.unroute('**/models/glucotwin_anatomy.glb');
  await hero.getByRole('button',{name:'Restore Scene'}).click();
  await expect(hero).toHaveAttribute('data-scene-status','ready',{timeout:20000});
  await page.getByTestId('landing-introduction').getByRole('link',{name:/Model evidence/}).click();
  await expect(page.getByRole('heading',{level:1})).toHaveText('What the prototype demonstrates');
  expect(errors).toEqual([]);
});
